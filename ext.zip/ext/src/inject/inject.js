
// Code to record questions clicked by user //

var questions = document.getElementsByClassName("question-hyperlink")
for (i = 0; i < questions.length; i++){
	questions[i].addEventListener("click", function(e){
		e = e || window.event;
    var target = e.target || e.srcElement,
        text = target.textContent || text.innerText;
		chrome.runtime.sendMessage({action: "clicked : ", item: "question : "+text});
	});
}

// code to record user clicks on vote-up //

var voteUps = document.getElementsByClassName("vote-up-off")
for (i = 0; i < voteUps.length; i++){
	voteUps[i].addEventListener("click", function(e){
		e = e || window.event;
    var target = e.target || e.srcElement,
        text = target.textContent || text.innerText;
		var upVoteObejct = target.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.className;
		var upVoteId = target.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.getAttribute("data-" + upVoteObejct +"id");
		chrome.runtime.sendMessage({action: "clicked : ", item: "up voted : "+upVoteObejct + " : id=" + upVoteId});
	});
}

// code to record user clicks on vote-down //

var voteDowns = document.getElementsByClassName("vote-down-off")
for (i = 0; i < voteDowns.length; i++){
	voteDowns[i].addEventListener("click", function(e){
		e = e || window.event;
    var target = e.target || e.srcElement,
        text = target.textContent || text.innerText;
		var downVoteObejct = target.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.className;
		var downVoteId = target.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.getAttribute("data-" + downVoteObejct +"id");
		chrome.runtime.sendMessage({action: "clicked : ", item: "down voted : "+downVoteObejct + " : id=" + downVoteId});
	});
}

// code to record user click on favorite //

var markFavorite = document.getElementsByClassName("star-off")
for (i = 0; i < markFavorite.length; i++){
	markFavorite[i].addEventListener("click", function(e){
		e = e || window.event;
		var target = e.target || e.srcElement;
				questionId = target.parentNode.childNodes[1].getAttribute("value");
		var markFlag = target.className
		var message = "";
		if (markFlag == "star-off"){
			message = "marked favorite";
		}
		else {
			message = " un marked favorite";
		}
				chrome.runtime.sendMessage({action: "clicked : ", item: message +" : id="+ questionId});
	});
}

// function to set the scroll throttle //

function throttle(wait) {
  var time = Date.now();
  return function() {
    if ((time + wait - Date.now()) < 0) {
			chrome.runtime.sendMessage({action: "scrolled : ", item: document.URL});
      time = Date.now();
    }
  }
}

// code to record the scroll behavior //

window.addEventListener('scroll', throttle(500));


// code to record user posting answer and question //


var postButton = document.getElementById("submit-button")
postButton.addEventListener("click", function(e){
	e = e || window.event;
	var target = e.target || e.srcElement;
	postType = target.value;
	if(postType == "Post Your Answer") {
		message = "Posted an answer to question : id="
		id = target.parentNode.parentNode.childNodes[1].value;
		message = message + id
		}
		else {
			message = "Posted question";
		}
		chrome.runtime.sendMessage({action: "clicked : ", item: message});

});
