
// extension code which listens on content scripts messages //

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    var activityValue = request.action + " " + request.item;
  chrome.cookies.getAll({}, function(cookies) {
   for (var i in cookies) {
     if (cookies[i].domain == 'behavioral-monitoring-tool.herokuapp.com' && cookies[i].name == 'user' ) {
       user = cookies[i].value;
       if (user != undefined) {
         var xmlhttp = new XMLHttpRequest();
         xmlhttp.open("POST", "http://behavioral-monitoring-tool.herokuapp.com/userActivity");
         xmlhttp.setRequestHeader("Content-Type", "application/json");
         xmlhttp.send(JSON.stringify({ username: cookies[i].value, activity: activityValue}));
       }
}
}
  });
    sendResponse();
});
